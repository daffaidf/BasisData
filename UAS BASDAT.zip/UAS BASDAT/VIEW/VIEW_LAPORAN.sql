-- ==========================================
-- FILE 4: VIEWS (REPORTING)
-- ==========================================
USE db_sports_booking;

-- 1. View Jadwal (Untuk Staff)
CREATE OR REPLACE VIEW v_booking_schedule AS
SELECT 
    b.booking_id, 
    b.booking_date, 
    b.start_time, 
    b.end_time, 
    c.name AS customer_name, 
    f.field_name, 
    b.status
FROM bookings b
JOIN customers c ON b.customer_id = c.customer_id
JOIN fields f ON b.field_id = f.field_id;

-- 2. View Invoice Detail (Untuk Customer/Kasir)
CREATE OR REPLACE VIEW v_invoice_details AS
SELECT 
    b.booking_id,
    c.name AS customer,
    f.field_name,
    b.total_price AS field_price,
    IFNULL(SUM(er.price), 0) AS equipment_cost,
    (b.total_price + IFNULL(SUM(er.price), 0)) AS grand_total
FROM bookings b
JOIN customers c ON b.customer_id = c.customer_id
JOIN fields f ON b.field_id = f.field_id
LEFT JOIN equipment_rental er ON b.booking_id = er.booking_id
GROUP BY b.booking_id;

-- 3. View Pendapatan Bulanan (Untuk Manajer)
CREATE OR REPLACE VIEW v_monthly_revenue AS
SELECT 
    YEAR(payment_date) AS Year, 
    MONTHNAME(payment_date) AS Month, 
    SUM(amount) AS Revenue
FROM payments 
WHERE payment_status = 'paid'
GROUP BY Year, Month;