USE db_sports_booking;
SHOW INDEX FROM bookings;