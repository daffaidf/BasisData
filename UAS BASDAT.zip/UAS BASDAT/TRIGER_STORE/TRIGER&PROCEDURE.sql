-- ==========================================
-- FILE 2: TRIGGERS & PROCEDURES
-- ==========================================
USE db_sports_booking;

DELIMITER $$

-- 1. Trigger: Otomatis kurangi stok saat alat disewa
CREATE TRIGGER tg_reduce_stock_after_rent
AFTER INSERT ON equipment_rental
FOR EACH ROW
BEGIN
    UPDATE equipments 
    SET quantity = quantity - NEW.qty
    WHERE equipment_id = NEW.equipment_id;
END$$

-- 2. Stored Procedure: Transaksi Booking Lengkap (Satu Pintu)
CREATE PROCEDURE sp_create_booking_transaction(
    IN p_customer_id INT,
    IN p_field_id INT,
    IN p_date DATE,
    IN p_start TIME,
    IN p_end TIME,
    IN p_duration INT,
    IN p_field_price DECIMAL(10,2),
    IN p_equipment_id INT, -- Isi 0 jika tidak sewa alat
    IN p_qty INT,
    IN p_eq_price DECIMAL(10,2)
)
BEGIN
    DECLARE v_new_booking_id INT;
    
    -- Mulai Transaksi (ACID)
    START TRANSACTION;
    
    -- A. Insert Booking
    INSERT INTO bookings (customer_id, field_id, booking_date, start_time, end_time, duration, total_price, status)
    VALUES (p_customer_id, p_field_id, p_date, p_start, p_end, p_duration, p_field_price, 'pending');
    
    SET v_new_booking_id = LAST_INSERT_ID();
    
    -- B. Insert Sewa Alat (Jika ada)
    IF p_equipment_id > 0 THEN
        INSERT INTO equipment_rental (booking_id, equipment_id, qty, price)
        VALUES (v_new_booking_id, p_equipment_id, p_qty, p_eq_price);
        -- Trigger stok akan otomatis jalan disini
    END IF;
    
    -- C. Selesai
    COMMIT;
    SELECT v_new_booking_id AS 'BookingID', 'Transaction Success' AS Status;
END$$

DELIMITER ;