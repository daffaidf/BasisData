-- ==========================================
-- FILE 1: STRUKTUR DATABASE (DDL)
-- ==========================================

-- 1. Reset Database
DROP DATABASE IF EXISTS db_sports_booking;
CREATE DATABASE db_sports_booking;
USE db_sports_booking;

-- 2. Tabel Master Data (Tanpa Foreign Key)
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'staff', 'manager') DEFAULT 'staff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE fields (
    field_id INT AUTO_INCREMENT PRIMARY KEY,
    field_name VARCHAR(100) NOT NULL,
    field_type ENUM('Indoor', 'Outdoor', 'Synthetic', 'Parquet') NOT NULL,
    price_per_hour DECIMAL(10, 2) NOT NULL,
    status ENUM('active', 'maintenance') DEFAULT 'active'
);

CREATE TABLE equipments (
    equipment_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    rental_price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL,
    condition_status ENUM('good', 'damaged', 'maintenance') DEFAULT 'good'
);

CREATE TABLE promos (
    promo_id INT AUTO_INCREMENT PRIMARY KEY,
    promo_name VARCHAR(100) NOT NULL,
    discount_percent INT NOT NULL CHECK (discount_percent BETWEEN 0 AND 100),
    valid_from DATE NOT NULL,
    valid_until DATE NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active'
);

-- 3. Tabel Transaksi (Dengan Foreign Key)
CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    field_id INT NOT NULL, 
    booking_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    duration INT NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'paid', 'canceled', 'completed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE RESTRICT,
    FOREIGN KEY (field_id) REFERENCES fields(field_id) ON DELETE RESTRICT
);

CREATE TABLE booking_promos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    promo_id INT NOT NULL,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (promo_id) REFERENCES promos(promo_id) ON DELETE RESTRICT,
    CONSTRAINT unique_booking_promo UNIQUE (booking_id, promo_id)
);

CREATE TABLE equipment_rental (
    eq_rental_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    equipment_id INT NOT NULL,
    qty INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (equipment_id) REFERENCES equipments(equipment_id) ON DELETE RESTRICT
);

CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    payment_method ENUM('cash', 'transfer', 'e-wallet') NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    proof_file VARCHAR(255) NULL, 
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    payment_status ENUM('paid', 'failed', 'refunded') DEFAULT 'paid',
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
);

CREATE TABLE checkins (
    checkin_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    checkin_time DATETIME NOT NULL,
    checkout_time DATETIME NULL,
    extra_duration INT DEFAULT 0,
    extra_price DECIMAL(10, 2) DEFAULT 0,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
);

CREATE TABLE field_maintenance (
    maintenance_id INT AUTO_INCREMENT PRIMARY KEY,
    field_id INT NOT NULL,
    pic_name VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    description TEXT,
    status ENUM('scheduled', 'in_progress', 'completed') DEFAULT 'scheduled',
    FOREIGN KEY (field_id) REFERENCES fields(field_id) ON DELETE CASCADE
);

-- 4. Indexing (Optimasi)
ALTER TABLE bookings ADD INDEX idx_booking_schedule (booking_date, field_id);
ALTER TABLE customers ADD INDEX idx_customer_phone (phone);
ALTER TABLE fields ADD INDEX idx_field_status (status);