-- ==========================================
-- FILE 3: DATA DUMMY (DML)
-- ==========================================
USE db_sports_booking;

-- 1. Isi Data Master (Users, Customers, Fields, Equipments)
INSERT INTO users (username, password, role) VALUES 
('admin01', 'admin123', 'admin'),
('staff01', 'staff123', 'staff'),
('manager01', 'boss123', 'manager');

INSERT INTO customers (name, phone, email, address) VALUES 
('Budi Santoso', '081234567890', 'budi@mail.com', 'Jakarta Selatan'),
('Siti Aminah', '081298765432', 'siti@mail.com', 'Tangerang Kota');

INSERT INTO fields (field_name, field_type, price_per_hour, status) VALUES 
('Lapangan Futsal A (Vinyl)', 'Indoor', 100000, 'active'),
('Lapangan Badminton B', 'Parquet', 50000, 'active');

INSERT INTO equipments (name, rental_price, quantity, condition_status) VALUES 
('Bola Futsal', 15000, 20, 'good'),
('Raket Yonex', 25000, 10, 'good');

-- 2. Isi Transaksi Menggunakan PROCEDURE (Biar terlihat canggih)
-- Format: (cust, field, tgl, start, end, durasi, harga_lap, id_alat, qty_alat, harga_alat)

-- Kasus 1: Budi Sewa Futsal + 2 Bola
CALL sp_create_booking_transaction(1, 1, '2025-12-30', '10:00:00', '12:00:00', 2, 200000, 1, 2, 30000);

-- Kasus 2: Siti Sewa Badminton Tanpa Alat (id_alat = 0)
CALL sp_create_booking_transaction(2, 2, '2025-12-31', '16:00:00', '17:00:00', 1, 50000, 0, 0, 0);

-- 3. Isi Pembayaran Manual (Untuk booking yg baru dibuat)
INSERT INTO payments (booking_id, payment_method, amount, payment_status) 
VALUES (1, 'transfer', 230000, 'paid');