-- ==================================================
-- SKENARIO TEKNISI: MAINTENANCE LAPANGAN
-- ==================================================
USE db_sports_booking;

-- 1. Cek Status Lapangan Saat Ini (Semua Active)
SELECT field_id, field_name, status FROM fields;

-- 2. Teknisi Lapor Kerusakan & Blokir Jadwal
-- Lapangan ID 2 (Badminton) akan diperbaiki besok
INSERT INTO field_maintenance (field_id, pic_name, start_date, end_date, description, status)
VALUES (2, 'Pak Asep', '2025-12-31', '2026-01-02', 'Lantai Parquet Menggelembung', 'scheduled');

-- 3. Ubah Status Master Lapangan jadi 'Maintenance'
UPDATE fields SET status = 'maintenance' WHERE field_id = 2;

-- 4. Buktikan Lapangan Sudah Tidak Bisa Disewa
SELECT field_id, field_name, status FROM fields;