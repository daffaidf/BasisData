-- ==================================================
-- SKENARIO MANAJER: LAPORAN BISNIS
-- ==================================================
USE db_sports_booking;

-- 1. Laporan Pendapatan Bulanan (Pake View)
SELECT * FROM v_monthly_revenue;

-- 2. Laporan Lapangan Paling Laris (Analisis)
SELECT 
    f.field_name, 
    COUNT(b.booking_id) as total_sewa 
FROM bookings b
JOIN fields f ON b.field_id = f.field_id
WHERE b.status = 'paid'
GROUP BY f.field_name
ORDER BY total_sewa DESC;

-- 3. Cek Stok Alat (Memastikan Trigger stok berkurang jalan)
-- Tadi Budi sewa 2 Rompi. Stok awal 5. Harusnya sisa 3.
SELECT * FROM equipments;