-- ==================================================
-- SKENARIO CUSTOMER: MELAKUKAN BOOKING
-- ==================================================
USE db_sports_booking;

-- 1. Customer Cek Jadwal Dulu (Memastikan kosong)
SELECT * FROM v_booking_schedule 
WHERE booking_date = '2025-12-30';

-- 2. Customer Melakukan Booking (Satu paket dengan sewa alat)
-- Kita pakai Stored Procedure biar cepat (One-Click Booking)
-- (Cust=1, Field=1, Tgl=30 Des, Jam 14-16, Durasi=2, Harga=200k, Alat=2 (Rompi), Qty=2, HargaAlat=40k)
CALL sp_create_booking_transaction(1, 1, '2025-12-30', '14:00:00', '16:00:00', 2, 200000, 2, 2, 40000);

-- 3. Customer Cek Invoice (Status harusnya masih PENDING)
-- Perhatikan ID Booking paling baru (misal ID = 3)
SELECT * FROM v_invoice_details 
ORDER BY booking_id DESC 
LIMIT 1;

-- (Ingat ID booking yang baru muncul ini untuk langkah selanjutnya!)
-- Misal kita asumsikan ID booking yang baru dibuat adalah ID: 3
SET @id_demo = 3;