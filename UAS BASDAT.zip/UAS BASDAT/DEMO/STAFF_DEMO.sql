-- ==================================================
-- SKENARIO STAFF: OPERASIONAL LAPANGAN
-- ==================================================
USE db_sports_booking;

SET @id_demo = 3; -- ID Booking Budi tadi

-- 1. Staff Cek Jadwal Hari Ini
-- (Melihat siapa saja yang akan main)
SELECT * FROM v_booking_schedule 
WHERE booking_date = '2025-12-30';

-- 2. Proses Check-in (Budi datang jam 13:55)
INSERT INTO checkins (booking_id, checkin_time) 
VALUES (@id_demo, '2025-12-30 13:55:00');

-- 3. Cek Data Checkin
SELECT * FROM checkins WHERE booking_id = @id_demo;