-- ==================================================
-- SKENARIO ADMIN: VALIDASI PEMBAYARAN
-- ==================================================
USE db_sports_booking;

-- Ganti angka 3 ini dengan ID Booking yang baru dibuat di Demo 1
SET @id_demo = 3; 

-- 1. Admin Cek Booking yang Masih 'Pending'
SELECT * FROM bookings WHERE status = 'pending';

-- 2. Admin Input Data Pembayaran (Setelah terima bukti transfer)
INSERT INTO payments (booking_id, payment_method, amount, payment_status) 
VALUES (@id_demo, 'transfer', 240000, 'paid');

-- 3. Admin Update Status Booking jadi 'Paid'
UPDATE bookings 
SET status = 'paid' 
WHERE booking_id = @id_demo;

-- 4. Buktikan Data Sudah Update
SELECT booking_id, status FROM bookings WHERE booking_id = @id_demo;