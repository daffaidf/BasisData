-- ==========================================
-- FILE 6: CEK SELURUH DATA (AUDIT SCRIPT)
-- ==========================================
-- Jalankan file ini untuk memastikan semua data sudah masuk dengan benar.
-- Di MySQL Workbench, hasil akan muncul dalam beberapa tab "Result Grid" di bawah.

USE db_sports_booking;

-- ==========================================
-- 1. CEK MASTER DATA
-- ==========================================
SELECT 'DATA USERS' AS TABLE_NAME;
SELECT * FROM users;

SELECT 'DATA CUSTOMERS' AS TABLE_NAME;
SELECT * FROM customers;

SELECT 'DATA FIELDS (LAPANGAN)' AS TABLE_NAME;
SELECT * FROM fields;

SELECT 'DATA EQUIPMENTS (ALAT)' AS TABLE_NAME;
SELECT * FROM equipments;

SELECT 'DATA PROMOS' AS TABLE_NAME;
SELECT * FROM promos;

-- ==========================================
-- 2. CEK DATA TRANSAKSI
-- ==========================================
SELECT 'DATA BOOKINGS' AS TABLE_NAME;
SELECT * FROM bookings;

SELECT 'DATA DETAIL SEWA ALAT' AS TABLE_NAME;
SELECT * FROM equipment_rental;

SELECT 'DATA PENGGUNAAN PROMO' AS TABLE_NAME;
SELECT * FROM booking_promos;

SELECT 'DATA PEMBAYARAN' AS TABLE_NAME;
SELECT * FROM payments;

SELECT 'DATA CHECK-INS' AS TABLE_NAME;
SELECT * FROM checkins;

SELECT 'DATA MAINTENANCE' AS TABLE_NAME;
SELECT * FROM field_maintenance;

-- ==========================================
-- 3. CEK HASIL LAPORAN (VIEWS)
-- ==========================================
SELECT 'VIEW: JADWAL HARIAN' AS REPORT_NAME;
SELECT * FROM v_booking_schedule;

SELECT 'VIEW: DETAIL INVOICE' AS REPORT_NAME;
SELECT * FROM v_invoice_details;

SELECT 'VIEW: PENDAPATAN BULANAN' AS REPORT_NAME;
SELECT * FROM v_monthly_revenue;

SELECT * FROM v_booking_schedule;